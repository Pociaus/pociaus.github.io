# quiz-app
A pure HTML/CSS/JS Quiz App created in a Udemy Course
